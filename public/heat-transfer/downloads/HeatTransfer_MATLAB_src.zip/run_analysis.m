% run_analysis.m
% ─────────────────────────────────────────────────────────────────────────────
% Web-app MATLAB entry point for the Heat Transfer Next.js dashboard.
%
% Called by the Next.js API route via:
%   matlab -batch "run('/abs/path/to/matlab/run_analysis.m')"
% with two environment variables:
%   HT_INPUT_FILE  – path to a JSON file describing the run
%   HT_OUTPUT_FILE – path where this script writes JSON results
%
% Input JSON schema:
%   {
%     "stack":        ["mat1","mat2"],   % air→hotplate order
%     "imagePath":    "/abs/path/image.png",
%     "hotPlateTemp": 230,               % °F
%     "airTemp":      59,                % °F
%     "kConstants":   {"acrylic":0.209, ...},
%     "L":            0.0254,            % optional (m)
%     "A":            0.000645           % optional (m²)
%   }
%
% Output JSON schema (physically correct metrics — no % error):
%   {
%     "profile_x":          [...],   % position  (0=Air … n+1=Hotplate)
%     "profile_y":          [...],   % temperature °C
%     "xLabels":            ["Air","mat1",…,"Hotplate"],
%     "layers": [{
%         "material":  "...",
%         "k":         ...,          % W/m·K
%         "R":         ...,          % K/W
%         "pctR":      ...,          % % of R_total
%         "tLow":      ...,          % °C  cool-side boundary
%         "tHigh":     ...,          % °C  hot-side boundary
%         "Q":         ...,          % W   per-layer Fourier Q
%         "qFlux":     ...           % W/m²
%     }],
%     "contacts": [{
%         "label":   "matA → matB",
%         "deltaT":  ...,            % °C  temperature jump
%         "Rc":      ...,            % K/W contact resistance
%         "pctR":    ...,            % % of R_total
%         "hc":      ...             % W/m²·K  contact conductance
%     }],
%     "summary": {
%         "Q":                  ..., % W    mean per-layer Fourier Q
%         "qFlux":              ..., % W/m²
%         "thetaTotal":         ..., % K/W  thermal impedance
%         "zSpecific":          ..., % K·cm²/W  specific impedance (×1e4)
%         "kEffBulk":           ..., % W/m·K
%         "kEffWithContact":    ..., % W/m·K
%         "steadyStateIndex":   ..., % %
%         "contactDominance":   ..., % %
%         "totalContactDeltaT": ..., % °C
%         "rBulkTotal":         ..., % K/W
%         "rContactTotal":      ...  % K/W
%     }
%   }
%
% Algorithm mirrors HeatGraph.m + QCalcAndError.m exactly.
% Authors: Taylor Houghtaling, Adityasriram Josyula, Enoch Choi
% ─────────────────────────────────────────────────────────────────────────────

set(0, 'DefaultFigureVisible', 'off');

%% ── 1. Environment variables ─────────────────────────────────────────────────
inputFile  = getenv('HT_INPUT_FILE');
outputFile = getenv('HT_OUTPUT_FILE');
if isempty(inputFile) || isempty(outputFile)
    error('run_analysis:missingEnv', ...
        'HT_INPUT_FILE and HT_OUTPUT_FILE must be set.');
end

%% ── 2. Parse input JSON ──────────────────────────────────────────────────────
inp          = jsondecode(fileread(inputFile));
stack        = cellstr(inp.stack);       % cell array, air→hotplate
im           = char(inp.imagePath);
hotPlateTemp = inp.hotPlateTemp;         % °F
airTemp      = inp.airTemp;              % °F
customK      = inp.kConstants;           % struct: field → k  (W/m·K)

L = 0.0254;   if isfield(inp,'L') && inp.L > 0,  L = inp.L;  end
A = 0.0254^2; if isfield(inp,'A') && inp.A > 0,  A = inp.A;  end

%% ── 3. Build k-constant lookup ───────────────────────────────────────────────
kFields = fieldnames(customK);
kVals   = zeros(numel(kFields), 1);
for idx = 1:numel(kFields)
    kVals(idx) = customK.(kFields{idx});
end

%% ── 4. Image → per-row mean temperature (mirrors HeatGraph.m) ───────────────
imArray = imread(im);
if size(imArray, 3) >= 3
    imGray = rgb2gray(imArray(:,:,1:3));
else
    imGray = imArray;
end
meanIntensity = double(mean(imGray, 2));

T_max = (hotPlateTemp - 32) * 5/9;   % °C
T_min = (airTemp      - 32) * 5/9;   % °C
minI  = min(meanIntensity);
maxI  = max(meanIntensity);
intensToTemp = T_min + (T_max - T_min) .* ...
               (meanIntensity - minI) ./ (maxI - minI);

%% ── 5. Sample profile — MATLAB boundary-index logic (mirrors HeatGraph.m) ────
N     = 15;
n     = numel(stack);
total = n * N + 2;

indices   = round(linspace(1, length(intensToTemp), total));
x_profile = linspace(0, n + 1, total);
y_profile = intensToTemp(indices)';   % row vector

%% ── 6. Extract per-layer boundary temperatures ────────────────────────────────
tLow_arr  = zeros(1, n);
tHigh_arr = zeros(1, n);

for i = 1:n
    block_start = N*(i-1) + 2;
    block_end   = N*i + 1;
    cool_idx    = block_start + (i == 1);
    hot_idx     = block_end   - (i  >  1);
    tLow_arr(i)  = y_profile(cool_idx);
    tHigh_arr(i) = y_profile(hot_idx);
end

%% ── 7. Per-layer bulk resistance & Fourier Q ─────────────────────────────────
k_arr    = zeros(1, n);
R_arr    = zeros(1, n);
Q_arr    = zeros(1, n);

for i = 1:n
    mat   = stack{i};
    k_val = 0;
    for j = 1:numel(kFields)
        if strcmp(kFields{j}, mat)
            k_val = kVals(j);
            break;
        end
    end
    if k_val > 0
        R_arr(i) = L / (k_val * A);
        Q_arr(i) = (tHigh_arr(i) - tLow_arr(i)) / R_arr(i);
    else
        R_arr(i) = Inf;
        Q_arr(i) = 0;
        warning('run_analysis:unknownMaterial', ...
            'Material "%s" not in kConstants.', mat);
    end
    k_arr(i) = k_val;
end

R_bulk_total = sum(R_arr(isfinite(R_arr)));

%% ── 8. Mean Q & Steady-State Index ──────────────────────────────────────────
Q_mean = mean(Q_arr);
Q_std  = std(Q_arr, 1);
SSI    = 0;
if Q_mean ~= 0,  SSI = (Q_std / abs(Q_mean)) * 100;  end
q_flux = Q_mean / A;

%% ── 9. Contact resistance at each interface ──────────────────────────────────
nc = n - 1;
contacts_out = struct('label',{},'deltaT',{},'Rc',{},'pctR',{},'hc',{});
R_contact_total    = 0;
totalContactDeltaT = 0;
dT_c  = zeros(1, nc);
Rc_c  = zeros(1, nc);
hc_c  = zeros(1, nc);

for i = 1:nc
    dT_c(i) = tLow_arr(i+1) - tHigh_arr(i);
    if Q_mean ~= 0
        Rc_c(i) = dT_c(i) / Q_mean;
    end
    if A > 0 && dT_c(i) > 0 && Q_mean > 0
        hc_c(i) = Q_mean / (A * dT_c(i));
    end
    R_contact_total    = R_contact_total + Rc_c(i);
    totalContactDeltaT = totalContactDeltaT + dT_c(i);
    contacts_out(i).label  = [stack{i} ' → ' stack{i+1}];
    contacts_out(i).deltaT = dT_c(i);
    contacts_out(i).Rc     = Rc_c(i);
    contacts_out(i).pctR   = 0;   % back-filled below
    contacts_out(i).hc     = hc_c(i);
end

R_total = R_bulk_total + R_contact_total;

%% ── 10. Back-fill %R ──────────────────────────────────────────────────────────
pctR_layer = zeros(1, n);
if R_total > 0
    pctR_layer = (R_arr / R_total) * 100;
    for i = 1:nc
        contacts_out(i).pctR = (Rc_c(i) / R_total) * 100;
    end
end

%% ── 11. Aggregate metrics ─────────────────────────────────────────────────────
realDeltaT  = max(intensToTemp) - min(intensToTemp);
theta_total = 0;
if Q_mean ~= 0,  theta_total = realDeltaT / Q_mean;  end

Z_specific_cm2 = theta_total * A * 1e4;          % K·cm²/W

L_total = n * L;
k_eff_bulk         = 0;
k_eff_with_contact = 0;
if R_bulk_total > 0,  k_eff_bulk = L_total / (A * R_bulk_total);  end
if R_total > 0,       k_eff_with_contact = L_total / (A * R_total);  end

contactDominance = 0;
if R_total > 0,  contactDominance = (R_contact_total / R_total) * 100;  end

%% ── 12. Build output struct ───────────────────────────────────────────────────
xLabels = [{'Air'}, stack(:)', {'Hotplate'}];

layersOut = struct( ...
    'material',{},'k',{},'R',{},'pctR',{},'tLow',{},'tHigh',{},'Q',{},'qFlux',{});
for i = 1:n
    layersOut(i).material = stack{i};
    layersOut(i).k        = k_arr(i);
    layersOut(i).R        = R_arr(i);
    layersOut(i).pctR     = pctR_layer(i);
    layersOut(i).tLow     = tLow_arr(i);
    layersOut(i).tHigh    = tHigh_arr(i);
    layersOut(i).Q        = Q_arr(i);
    layersOut(i).qFlux    = (A > 0) * Q_arr(i) / A;
end

result.profile_x   = x_profile(:);
result.profile_y   = y_profile(:);
result.xLabels     = xLabels;
result.layers      = layersOut;
if nc > 0
    result.contacts = contacts_out;
else
    result.contacts = struct([]);
end
result.summary = struct( ...
    'Q',                  Q_mean, ...
    'qFlux',              q_flux, ...
    'thetaTotal',         theta_total, ...
    'zSpecific',          Z_specific_cm2, ...
    'kEffBulk',           k_eff_bulk, ...
    'kEffWithContact',    k_eff_with_contact, ...
    'steadyStateIndex',   SSI, ...
    'contactDominance',   contactDominance, ...
    'totalContactDeltaT', totalContactDeltaT, ...
    'rBulkTotal',         R_bulk_total, ...
    'rContactTotal',      R_contact_total);

%% ── 13. Write JSON ────────────────────────────────────────────────────────────
fid = fopen(outputFile, 'w');
if fid == -1
    error('run_analysis:outputFile', 'Cannot open output file: %s', outputFile);
end
fwrite(fid, jsonencode(result, 'PrettyPrint', false), 'char');
fclose(fid);
