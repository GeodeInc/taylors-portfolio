% Authors: Taylor Houghtaling, Adityasriram Josyula, Enoch Choi
% Course:  ID3EA II
% Date:    04/09/2026
% Function:HeatGraph.m
%
% Description:
%   Processes FLIR thermal images of a composite material stack, extracts
%   per-row temperature profiles, samples boundary temperatures using the
%   MATLAB boundary-index algorithm, and computes physically correct 1-D
%   steady-state heat-transfer metrics.
%
%   Key principle: in 1-D steady-state series conduction the same Q flows
%   through every layer.  Q_i = k_i·A·ΔT_i / L  (Fourier's law per layer);
%   the mean of all Q_i is the best single estimate.  Spread (Steady-State
%   Index) is the primary quality metric — NOT a % error against theoretical.
%
% Inputs:
%   stacks       – (1×m) cell array of (1×n) cell arrays of material names
%                  each inner array is one test case, air→hotplate order
%   imageFiles   – (1×m) cell array of image file paths  (same length as stacks)
%   hotPlateTemp – hotplate surface temperature  (°F)
%   airTemp      – ambient / air temperature     (°F)
%   L            – (optional) layer thickness (m)    default 0.0254
%   A            – (optional) cross-section area (m²) default 0.0254²
%
% Outputs:
%   profiles     – (1×m) cell of structs with fields:
%                    .x  (position 0=Air … n+1=Hotplate)
%                    .y  (temperature °C)
%   layerTables  – (1×m) cell of per-layer MATLAB tables
%   contactTables– (1×m) cell of contact-interface MATLAB tables
%   summaryTables– (1×m) cell of summary-metric MATLAB tables
%
% Dependencies:  QCalcAndError.m, infoTableMaker.m

function [profiles, layerTables, contactTables, summaryTables] = ...
    HeatGraph(stacks, imageFiles, hotPlateTemp, airTemp, L, A)

if nargin < 5 || isempty(L),  L = 0.0254;   end
if nargin < 6 || isempty(A),  A = 0.0254^2; end

m = numel(stacks);
profiles      = cell(1, m);
layerTables   = cell(1, m);
contactTables = cell(1, m);
summaryTables = cell(1, m);

%% ── Convert boundary temperatures to °C ──────────────────────────────────────
T_max = (hotPlateTemp - 32) * 5/9;   % hotplate °C
T_min = (airTemp      - 32) * 5/9;   % air      °C

N = 15;   % interior sample points per layer (mirrors original algorithm)

for m_idx = 1:m
    stack   = stacks{m_idx};
    imFile  = imageFiles{m_idx};
    n       = numel(stack);

    %% ── Image → per-row mean temperature ─────────────────────────────────────
    imArray = imread(imFile);
    if size(imArray, 3) >= 3
        imGray = rgb2gray(imArray(:,:,1:3));
    else
        imGray = imArray;
    end
    meanIntensity = double(mean(imGray, 2));

    minI = min(meanIntensity);
    maxI = max(meanIntensity);
    if maxI == minI
        error('HeatGraph:uniformImage', ...
            'Image "%s" has uniform intensity — cannot extract profile.', imFile);
    end
    intensToTemp = T_min + (T_max - T_min) .* ...
                   (meanIntensity - minI) ./ (maxI - minI);

    %% ── Sample profile — MATLAB boundary-index logic (1-indexed) ─────────────
    total     = n * N + 2;
    indices   = round(linspace(1, length(intensToTemp), total));
    x_profile = linspace(0, n + 1, total);
    y_profile = intensToTemp(indices)';   % row vector

    profiles{m_idx}.x = x_profile;
    profiles{m_idx}.y = y_profile;

    %% ── Extract per-layer boundary temperatures ───────────────────────────────
    tLow_arr  = zeros(1, n);
    tHigh_arr = zeros(1, n);

    for i = 1:n
        block_start = N*(i-1) + 2;
        block_end   = N*i + 1;
        cool_idx    = block_start + (i == 1);   % +1 for first layer
        hot_idx     = block_end   - (i  >  1);  % -1 for all subsequent layers
        tLow_arr(i)  = y_profile(cool_idx);
        tHigh_arr(i) = y_profile(hot_idx);
    end

    %% ── Build temps cell array for QCalcAndError ─────────────────────────────
    temps = cell(n, 3);
    for i = 1:n
        temps{i,1} = stack{i};
        temps{i,2} = tLow_arr(i);
        temps{i,3} = tHigh_arr(i);
    end

    %% ── Compute metrics & display ─────────────────────────────────────────────
    fprintf('\n[HeatGraph]  Test %d / %d  —  stack: %s\n', ...
        m_idx, m, strjoin(stack, ' | '));

    [lT, cT, sT] = infoTableMaker(stack, temps, T_min, T_max, L, A);
    layerTables{m_idx}   = lT;
    contactTables{m_idx} = cT;
    summaryTables{m_idx} = sT;

    %% ── Plot temperature profile ──────────────────────────────────────────────
    figure('Name', sprintf('Temperature Profile — Test %d', m_idx), ...
           'NumberTitle', 'off');
    plot(x_profile, y_profile, 'b-', 'LineWidth', 1.5);
    hold on;

    % Boundary marker dots
    colors_hot  = [0.85 0.33 0.10];   % orange  = T_hot  side
    colors_cool = [0.00 0.45 0.74];   % blue    = T_cool side
    xLabels = [{'Air'}, stack(:)', {'Hotplate'}];
    xticks(0:n+1);
    xticklabels(xLabels);

    for i = 1:n
        blk_s    = N*(i-1) + 2;
        blk_e    = N*i + 1;
        cool_idx = blk_s + (i == 1);
        hot_idx  = blk_e - (i  >  1);
        plot(x_profile(cool_idx), y_profile(cool_idx), 'o', ...
            'Color', colors_cool, 'MarkerFaceColor', colors_cool, 'MarkerSize', 7);
        plot(x_profile(hot_idx),  y_profile(hot_idx),  's', ...
            'Color', colors_hot,  'MarkerFaceColor', colors_hot,  'MarkerSize', 7);
    end

    xlabel('Position  (0 = Air  →  n+1 = Hotplate)');
    ylabel('Temperature (°C)');
    title(sprintf('Thermal Profile — %s', strjoin(stack, ' | ')));
    legend({'Profile', 'T_2 cool side', 'T_1 hot side'}, 'Location', 'best');
    grid on;
    hold off;
end

end
