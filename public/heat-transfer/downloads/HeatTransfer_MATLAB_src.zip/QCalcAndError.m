% Authors: Taylor Houghtaling, Adityasriram Josyula, Enoch Choi
% Course:  ID3EA II
% Date:    04/09/2026
% Function:QCalcAndError.m
%
% Description:
%   Computes physically correct 1-D steady-state heat-transfer metrics for
%   a composite material stack imaged with a FLIR thermal camera.
%
%   Key principle: in 1-D steady-state series conduction the same Q flows
%   through every layer.  Q is derived from Fourier's law applied to each
%   layer individually; the mean is the best single estimate and the spread
%   (Steady-State Index) is the primary quality metric.
%
%   Metrics returned:
%     Q          – mean per-layer Fourier heat-flow rate (W)
%     q''        – heat flux = Q / A  (W/m²)
%     theta      – thermal impedance = (T_hot − T_air) / Q  (K/W)
%     Z_specific – specific thermal impedance = theta × A × 1e4  (K·cm²/W)
%     k_eff      – effective conductivity bulk-only and with-contact  (W/m·K)
%     h_c        – contact conductance per interface  (W/m²·K)
%     SSI        – steady-state index = sigma(Q_i)/mean(Q_i) × 100 %
%     contactDom – R_contact / R_total × 100 %
%
% Inputs:
%   temps  – (n×3) cell array:  {material_name, tLow_°C, tHigh_°C}
%              each row is one layer, air→hotplate order
%   T_air  – ambient / air temperature  (°C)
%   T_hot  – hotplate surface temperature (°C)
%   L      – (optional) layer thickness  (m)   default: 0.0254 m (1 inch)
%   A      – (optional) cross-section area (m²) default: 0.0254² m²
%
% Outputs:
%   layerTable   – MATLAB table: per-layer results
%   contactTable – MATLAB table: per-interface contact results (empty if n=1)
%   summaryTable – MATLAB table: aggregate scalar metrics
%
% Dependencies:  (none — self-contained)

function [layerTable, contactTable, summaryTable] = ...
    QCalcAndError(temps, T_air, T_hot, L, A)

%% ── Defaults ──────────────────────────────────────────────────────────────────
if nargin < 4 || isempty(L),  L = 0.0254;        end   % 1 inch in metres
if nargin < 5 || isempty(A),  A = 0.0254^2;      end   % 1 in² in m²

%% ── k-constant dictionary (W/m·K) ────────────────────────────────────────────
kConst = dictionary( ...
    ["acrylic","PVC","pine","aluminum","copper","steel"], ...
    [0.209,    0.251, 0.343, 225.94,   397.48,  71.128]);

%% ── Unpack layer inputs ───────────────────────────────────────────────────────
n        = size(temps, 1);
stack    = string(temps(:,1));
tLow     = cell2mat(temps(:,2));   % cool-side boundary (°C), column vector
tHigh    = cell2mat(temps(:,3));   % hot-side boundary  (°C), column vector

%% ── Per-layer bulk resistance & Fourier Q ─────────────────────────────────────
k_vals   = zeros(n, 1);
R_vals   = zeros(n, 1);
Q_vals   = zeros(n, 1);

for i = 1:n
    mat = stack(i);
    if isKey(kConst, mat)
        k_vals(i) = kConst(mat);
    else
        warning('QCalcAndError:unknownMaterial', ...
            'Material "%s" not in k-dictionary; k set to 0.', mat);
        k_vals(i) = 0;
    end
    if k_vals(i) > 0
        R_vals(i) = L / (k_vals(i) * A);
        Q_vals(i) = (tHigh(i) - tLow(i)) / R_vals(i);   % Fourier's law
    else
        R_vals(i) = Inf;
        Q_vals(i) = 0;
    end
end

R_bulk_total = sum(R_vals(isfinite(R_vals)));

%% ── Mean Q (best estimate) & Steady-State Index ───────────────────────────────
Q_mean = mean(Q_vals);
Q_std  = std(Q_vals, 1);                       % population std
SSI    = 0;
if Q_mean ~= 0,  SSI = (Q_std / abs(Q_mean)) * 100;  end

q_flux = Q_mean / A;                           % W/m²

%% ── Contact resistance at each interface ──────────────────────────────────────
nc          = n - 1;
labels_c    = strings(nc, 1);
deltaT_c    = zeros(nc, 1);
Rc_vals     = zeros(nc, 1);
hc_vals     = zeros(nc, 1);
pctR_c      = zeros(nc, 1);   % filled after R_total is known
R_contact_total   = 0;
totalContactDeltaT = 0;

for i = 1:nc
    labels_c(i) = stack(i) + " → " + stack(i+1);
    deltaT_c(i) = tLow(i+1) - tHigh(i);          % temperature jump at interface
    if Q_mean ~= 0
        Rc_vals(i) = deltaT_c(i) / Q_mean;        % R_c = ΔT / Q
    end
    if A > 0 && deltaT_c(i) > 0 && Q_mean > 0
        hc_vals(i) = Q_mean / (A * deltaT_c(i));  % h_c = Q / (A·ΔT)
    end
    R_contact_total    = R_contact_total    + Rc_vals(i);
    totalContactDeltaT = totalContactDeltaT + deltaT_c(i);
end

R_total = R_bulk_total + R_contact_total;

%% ── Back-fill %R ──────────────────────────────────────────────────────────────
pctR_layer = zeros(n, 1);
if R_total > 0
    pctR_layer = (R_vals / R_total) * 100;
    for i = 1:nc
        pctR_c(i) = (Rc_vals(i) / R_total) * 100;
    end
end

%% ── Thermal impedance & effective conductivity ────────────────────────────────
realDeltaT  = T_hot - T_air;                      % full measured span (°C/K)
theta_total = 0;
if Q_mean ~= 0,  theta_total = realDeltaT / Q_mean;  end

Z_specific_m2 = theta_total * A;                  % K·m²/W
Z_specific_cm2 = Z_specific_m2 * 1e4;            % K·cm²/W  (TIM standard)

L_total = n * L;
k_eff_bulk        = 0;
k_eff_with_contact = 0;
if R_bulk_total > 0
    k_eff_bulk = L_total / (A * R_bulk_total);
end
if R_total > 0
    k_eff_with_contact = L_total / (A * R_total);
end

contactDominance = 0;
if R_total > 0,  contactDominance = (R_contact_total / R_total) * 100;  end

%% ── Build per-layer output table ──────────────────────────────────────────────
qFlux_layer = Q_vals / A;

layerTable = table( ...
    stack,              ...
    k_vals,             ...
    R_vals,             ...
    pctR_layer,         ...
    tLow,               ...
    tHigh,              ...
    Q_vals,             ...
    qFlux_layer,        ...
    'VariableNames', {'Material','k_W_mK','R_KW','pctR_total',...
                      'T2_cool_C','T1_hot_C','Q_W','qFlux_Wm2'});

%% ── Build contact-interface output table ──────────────────────────────────────
if nc > 0
    contactTable = table( ...
        labels_c,   ...
        deltaT_c,   ...
        Rc_vals,    ...
        pctR_c,     ...
        hc_vals,    ...
        'VariableNames', {'Interface','deltaT_C','Rc_KW','pctR_total','hc_Wm2K'});
else
    contactTable = table();
end

%% ── Build summary table ───────────────────────────────────────────────────────
MetricName = { ...
    'Q_mean (W)';
    'q_flux (W/m²)';
    'theta_total (K/W)';
    'Z_specific (K·cm²/W)';
    'k_eff_bulk (W/m·K)';
    'k_eff_with_contact (W/m·K)';
    'R_bulk_total (K/W)';
    'R_contact_total (K/W)';
    'Contact_Dominance (%)';
    'TotalContact_DeltaT (°C)';
    'SteadyState_Index (%)';
};
Value = { ...
    Q_mean;
    q_flux;
    theta_total;
    Z_specific_cm2;
    k_eff_bulk;
    k_eff_with_contact;
    R_bulk_total;
    R_contact_total;
    contactDominance;
    totalContactDeltaT;
    SSI;
};
summaryTable = table(MetricName, Value, 'VariableNames', {'Metric','Value'});

end
