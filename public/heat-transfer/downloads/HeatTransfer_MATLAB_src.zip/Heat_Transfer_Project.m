% Authors: Taylor Houghtaling, Adityasriram Josyula, Enoch Choi
% Course:  ID3EA II
% Date:    04/09/2026
% File:    Heat_Transfer_Project.m
%
% Description:
%   Runs HeatGraph on metal and nonmetal material stacks across three test
%   cases using FLIR thermal images.  Outputs per-layer results, contact-
%   interface resistance, and summary metrics for each test.
%
%   Key metrics (replaces the broken % error):
%     Q_mean          – mean Fourier heat-flow rate (W)
%     q''             – heat flux (W/m²)
%     theta_total     – thermal impedance (K/W)
%     Z_specific      – specific impedance (K·cm²/W, for TIM comparison)
%     k_eff_bulk      – effective conductivity, bulk materials only (W/m·K)
%     k_eff_contact   – effective conductivity including interface R (W/m·K)
%     SteadyState_Idx – sigma(Q_i)/mean(Q_i) × 100 %  (<5 % = good steady state)
%     ContactDominance– R_contact / R_total × 100 %
%
% Dependencies:
%   HeatGraph.m, QCalcAndError.m, infoTableMaker.m

%% ── Material stacks ──────────────────────────────────────────────────────────
metals    = {"steel", "copper", "aluminum"};
nonmetals = {"acrylic", "PVC", "pine"};

%% ── Image file lists ─────────────────────────────────────────────────────────
metalTestImFiles    = {'metalsTest1.png',    'metalTest2.png',    'metalsTest3.png'};
nonmetalTestImFiles = {'nonmetalsTest1.png', 'nonmetalTest2.png', 'nonmetalsTest3.png'};

%% ── Test 1  (hotplate 230 °F, air 59 °F) ────────────────────────────────────
fprintf('\n══════════════════════════════════════════════════════════════\n');
fprintf('  TEST 1   |   Hotplate 230 °F   Air 59 °F\n');
fprintf('══════════════════════════════════════════════════════════════\n');

[~, layerT1, contactT1, summaryT1] = HeatGraph( ...
    {metals, nonmetals}, ...
    {metalTestImFiles{1}, nonmetalTestImFiles{1}}, ...
    230, 59);

fprintf('\n──  Test 1 – Metals  ──\n');
disp(layerT1{1});
if ~isempty(contactT1{1}),  disp(contactT1{1});  end
disp(summaryT1{1});

fprintf('\n──  Test 1 – Nonmetals  ──\n');
disp(layerT1{2});
if ~isempty(contactT1{2}),  disp(contactT1{2});  end
disp(summaryT1{2});

%% ── Test 2  (hotplate 175 °F, air 53 °F) ────────────────────────────────────
fprintf('\n══════════════════════════════════════════════════════════════\n');
fprintf('  TEST 2   |   Hotplate 175 °F   Air 53 °F\n');
fprintf('══════════════════════════════════════════════════════════════\n');

[~, layerT2, contactT2, summaryT2] = HeatGraph( ...
    {metals, nonmetals}, ...
    {metalTestImFiles{2}, nonmetalTestImFiles{2}}, ...
    175, 53);

fprintf('\n──  Test 2 – Metals  ──\n');
disp(layerT2{1});
if ~isempty(contactT2{1}),  disp(contactT2{1});  end
disp(summaryT2{1});

fprintf('\n──  Test 2 – Nonmetals  ──\n');
disp(layerT2{2});
if ~isempty(contactT2{2}),  disp(contactT2{2});  end
disp(summaryT2{2});

%% ── Test 3  (hotplate 247 °F, air 51 °F) ────────────────────────────────────
fprintf('\n══════════════════════════════════════════════════════════════\n');
fprintf('  TEST 3   |   Hotplate 247 °F   Air 51 °F\n');
fprintf('══════════════════════════════════════════════════════════════\n');

[~, layerT3, contactT3, summaryT3] = HeatGraph( ...
    {metals, nonmetals}, ...
    {metalTestImFiles{3}, nonmetalTestImFiles{3}}, ...
    247, 51);

fprintf('\n──  Test 3 – Metals  ──\n');
disp(layerT3{1});
if ~isempty(contactT3{1}),  disp(contactT3{1});  end
disp(summaryT3{1});

fprintf('\n──  Test 3 – Nonmetals  ──\n');
disp(layerT3{2});
if ~isempty(contactT3{2}),  disp(contactT3{2});  end
disp(summaryT3{2});

% Note: intentionally unrolled rather than looped for readability and
% explicit test-case traceability.
