% Authors: Taylor Houghtaling, Adityasriram Josyula, Enoch Choi
% Course:  ID3EA II
% Date:    04/09/2026
% Function:infoTableMaker.m
%
% Description:
%   Convenience wrapper — calls QCalcAndError and pretty-prints the three
%   result tables (per-layer, contact interfaces, summary) to the console.
%   Returns all three tables for programmatic use.
%
% Inputs:
%   stack      – (n×1) cell/string array of material names (air→hotplate)
%   temps      – (n×3) cell array: {material, tLow_°C, tHigh_°C}
%   T_air      – ambient temperature  (°C)
%   T_hot      – hotplate temperature (°C)
%   L          – (optional) layer thickness (m)   default 0.0254
%   A          – (optional) cross-section area (m²) default 0.0254²
%
% Outputs:
%   layerTable   – per-layer MATLAB table
%   contactTable – per-interface contact table
%   summaryTable – scalar summary metrics table

function [layerTable, contactTable, summaryTable] = ...
    infoTableMaker(stack, temps, T_air, T_hot, L, A)

if nargin < 5,  L = [];  end
if nargin < 6,  A = [];  end

%% ── Run computations ──────────────────────────────────────────────────────────
[layerTable, contactTable, summaryTable] = ...
    QCalcAndError(temps, T_air, T_hot, L, A);

%% ── Display results ───────────────────────────────────────────────────────────
fprintf('\n══════════════════════════════════════════════════════════════\n');
fprintf('  Heat-Transfer Analysis  —  %d material%s\n', ...
    numel(stack), iif(numel(stack)>1,'s',''));
fprintf('══════════════════════════════════════════════════════════════\n\n');

fprintf('── Per-Layer Results ─────────────────────────────────────────\n');
disp(layerTable);

if ~isempty(contactTable) && height(contactTable) > 0
    fprintf('── Contact-Interface Results ──────────────────────────────────\n');
    disp(contactTable);
end

fprintf('── Summary Metrics ───────────────────────────────────────────\n');
disp(summaryTable);
fprintf('══════════════════════════════════════════════════════════════\n\n');

end

%% ── Local helper (ternary) ────────────────────────────────────────────────────
function out = iif(cond, a, b)
    if cond, out = a; else, out = b; end
end
